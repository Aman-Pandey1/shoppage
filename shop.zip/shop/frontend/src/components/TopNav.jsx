import React from 'react';
import { fetchJson, getCurrentUser, logout } from '../lib/api';
import { useNavigate } from 'react-router-dom';

export const TopNav = ({ siteSlug = 'default', onSignIn, onOpenCart, cartCount = 0, isCartOpen = false }) => {
  const [site, setSite] = React.useState({ name: 'Store' });
  const [menuOpen, setMenuOpen] = React.useState(false);
  const user = getCurrentUser();
  const navigate = useNavigate();

  React.useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const data = await fetchJson(`/api/shop/${siteSlug}/site`);
        if (!cancelled) setSite(data || {});
      } catch {}
    }
    load();
    return () => { cancelled = true; };
  }, [siteSlug]);

  const name = site?.name || 'Store';
  const apiBase = (import.meta.env.VITE_API_URL || 'http://localhost:4000').replace(/\/$/, '');
  const logoSrc = React.useMemo(() => {
    const url = site?.logoUrl || '';
    if (!url) return '';
    if (/^https?:\/\//i.test(url)) return url;
    // For relative URLs like "/uploads/...", prefix API base so the image loads correctly in the frontend app
    return `${apiBase}${url.startsWith('/') ? url : `/${url}`}`;
  }, [site?.logoUrl, apiBase]);
  const initials = React.useMemo(() => {
    if (!user?.email) return 'FR';
    const base = (user?.email?.split('@')[0] || '').replace(/[^A-Za-z]/g, '');
    return base.slice(0, 2).toUpperCase() || 'FR';
  }, [user?.email]);

  return (
    <div className="top-nav" data-menu-open={menuOpen ? 'true' : 'false'} role="banner">
      <div className="top-nav__inner">
        <div className="brand" aria-label="Store brand">
          <div className="brand__logo" aria-hidden>
            {logoSrc ? (
              <img src={logoSrc} alt="logo" />
            ) : (
              <span>🍽️</span>
            )}
          </div>
          <div className="brand__text">
            <div className="brand__name">{name}</div>
            <div className="brand__tagline hide-mobile">Sweets, Catering & Pickup</div>
          </div>
        </div>
        {/* On mobile, when the cart is open we only show "Cart" at top */}
        <div className="nav-title">{isCartOpen ? 'Cart' : 'ONLINE ORDERING'}</div>

        <div className="actions" style={{ position: 'relative' }}>
          <button
            className="cart-header-btn"
            aria-label="Open cart"
            onClick={() => { if (typeof onOpenCart === 'function') onOpenCart(); }}
            title="Cart"
          >
            <span role="img" aria-label="cart">🛒</span>
            {Number(cartCount) > 0 ? (
              <span className="cart-header-badge" aria-label={`Items in cart: ${cartCount}`}>{cartCount}</span>
            ) : null}
          </button>
          <button className="profile-chip" aria-label="Account" onClick={() => setMenuOpen((v) => !v)}>
            <span>{initials}</span>
          </button>
          {!user ? (
            <button className="signin-btn" onClick={onSignIn}>Sign in</button>
          ) : null}
          {menuOpen ? (
            <div className="card" style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', padding: 8, borderRadius: 12, minWidth: 220, zIndex: 210 }} onMouseLeave={() => setMenuOpen(false)}>
              <div style={{ padding: '6px 10px', fontWeight: 700 }}>{user?.email || 'Account'}</div>
              <button style={{ width: '100%', textAlign: 'left', marginTop: 4 }} onClick={() => { setMenuOpen(false); navigate(`/s/${siteSlug}/orders`); }}>My Orders</button>
              {!user ? (
                <button style={{ width: '100%', textAlign: 'left' }} onClick={() => { setMenuOpen(false); onSignIn && onSignIn(); }}>Login / Register</button>
              ) : (
                <button style={{ width: '100%', textAlign: 'left' }} onClick={() => { logout(); setMenuOpen(false); window.location.reload(); }}>Logout</button>
              )}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};

