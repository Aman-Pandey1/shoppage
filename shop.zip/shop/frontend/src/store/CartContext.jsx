import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

const DEFAULT_STORAGE_KEY = 'shop_cart_state_v1';

const CartContext = createContext(undefined);

function calculateExtraCost(selectedOptions) {
  return (selectedOptions || []).reduce((sum, opt) => sum + (opt.priceDelta || 0), 0);
}

function formatOptionsSummary(product, spiceLevel, selectedOptions, variant) {
  try {
    const groups = Array.isArray(product?.extraOptionGroups) ? product.extraOptionGroups : [];
    const groupKeyToLabel = new Map(groups.map((g) => [g.groupKey, g.groupLabel || g.groupKey]));
    const groupKeyToOptions = new Map(groups.map((g) => [g.groupKey, new Map((g.options || []).map((o) => [o.key, o.label || o.key]))]));

    const perGroupSelections = new Map();
    (selectedOptions || []).forEach((opt) => {
      const labelMap = groupKeyToOptions.get(opt.groupKey);
      const optionLabel = labelMap ? (labelMap.get(opt.optionKey) || opt.optionKey) : opt.optionKey;
      if (!perGroupSelections.has(opt.groupKey)) perGroupSelections.set(opt.groupKey, []);
      perGroupSelections.get(opt.groupKey).push(optionLabel);
    });

    const parts = [];
    if (variant && (variant.label || variant.key)) parts.push(`Size: ${variant.label || variant.key}`);
    if (spiceLevel) parts.push(`Spice: ${spiceLevel}`);
    for (const [gk, labels] of perGroupSelections.entries()) {
      const glabel = groupKeyToLabel.get(gk) || gk;
      parts.push(`${glabel}: ${labels.join(', ')}`);
    }
    const summary = parts.join(' • ');
    return summary || undefined;
  } catch {
    return undefined;
  }
}

function generateItemId(productId, spiceLevel, selectedOptions, variant) {
  const optsKey = (selectedOptions || [])
    .slice()
    .sort((a, b) => `${a.groupKey}:${a.optionKey}`.localeCompare(`${b.groupKey}:${b.optionKey}`))
    .map((o) => `${o.groupKey}:${o.optionKey}`)
    .join('|');
  const variantKey = variant?.key || '';
  return `${productId}__${variantKey}__${spiceLevel || ''}__${optsKey}`;
}

export const CartProvider = ({ children, storageKey = DEFAULT_STORAGE_KEY }) => {
  const [state, setState] = useState({ items: [], notes: '', coupon: null });
  const [lastAdded, setLastAdded] = useState(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        setState(parsed);
      }
    } catch {}
  }, [storageKey]);

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(state));
    } catch {}
  }, [state, storageKey]);

  const setFulfillmentType = useCallback((type) => {
    setState((prev) => ({ ...prev, fulfillmentType: type }));
  }, []);

  const setNotes = useCallback((text) => {
    setState((prev) => ({ ...prev, notes: String(text || '').slice(0, 1000) }));
  }, []);

  const applyCoupon = useCallback((code, percent) => {
    const normalized = String(code || '').trim().toUpperCase();
    const pct = Math.max(0, Math.min(100, Number(percent) || 0));
    setState((prev) => ({ ...prev, coupon: normalized && pct > 0 ? { code: normalized, percent: pct } : null }));
  }, []);

  const clearCoupon = useCallback(() => setState((prev) => ({ ...prev, coupon: null })), []);

  const addItem = useCallback(({ product, quantity = 1, spiceLevel, selectedOptions = [], variant = null }) => {
    const extraCost = calculateExtraCost(selectedOptions);
    const variantDelta = variant?.priceDelta || 0;
    const unitPrice = product.price + variantDelta + extraCost;
    const totalPrice = unitPrice * quantity;
    const id = generateItemId(product._id, spiceLevel, selectedOptions, variant);
    const newItem = {
      id,
      productId: product._id,
      name: product.name,
      basePrice: product.price,
      variant,
      quantity,
      spiceLevel,
      selectedOptions,
      extraCost,
      totalPrice,
      imageUrl: product.imageUrl,
    };

    setState((prev) => {
      const existingIndex = prev.items.findIndex((it) => it.id === id);
      if (existingIndex >= 0) {
        const updated = prev.items.slice();
        const existing = updated[existingIndex];
        const newQuantity = existing.quantity + quantity;
        updated[existingIndex] = {
          ...existing,
          quantity: newQuantity,
          totalPrice: (existing.basePrice + (existing?.variant?.priceDelta || 0) + existing.extraCost) * newQuantity,
        };
        return { ...prev, items: updated };
      }
      return { ...prev, items: [...prev.items, newItem] };
    });
    const optionsSummary = formatOptionsSummary(product, spiceLevel, selectedOptions, variant);
    setLastAdded({ name: product.name, quantity, price: (product.price + variantDelta + extraCost), imageUrl: product.imageUrl, optionsSummary });
  }, []);

  const removeItem = useCallback((id) => {
    setState((prev) => ({ ...prev, items: prev.items.filter((it) => it.id !== id) }));
  }, []);

  const updateQuantity = useCallback((id, quantity) => {
    setState((prev) => {
      const updated = prev.items.map((it) => (it.id === id ? { ...it, quantity, totalPrice: (it.basePrice + it.extraCost) * quantity } : it));
      return { ...prev, items: updated };
    });
  }, []);

  const clearCart = useCallback(() => setState((prev) => ({ ...prev, items: [] })), []);

  const getCartTotal = useCallback(() => {
    const subtotal = state.items.reduce((sum, it) => sum + it.totalPrice, 0);
    const discount = state.coupon ? (subtotal * (state.coupon.percent / 100)) : 0;
    return Math.max(0, subtotal - discount);
  }, [state.items, state.coupon]);

  const value = useMemo(
    () => ({ state, setFulfillmentType, addItem, removeItem, updateQuantity, clearCart, getCartTotal, lastAdded, setNotes, applyCoupon, clearCoupon }),
    [state, setFulfillmentType, addItem, removeItem, updateQuantity, clearCart, getCartTotal, lastAdded, setNotes, applyCoupon, clearCoupon]
  );

  return (<CartContext.Provider value={value}>{children}</CartContext.Provider>);
};

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}

