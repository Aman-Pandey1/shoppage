import { Router } from 'express';
import Stripe from 'stripe';
import fetch from 'node-fetch';
import { createDelivery as uberCreateDelivery } from '../services/uberDirect.js';
import { createDelivery as ddCreateDelivery } from '../services/doordashDrive.js';
import { sendOrderEmail } from '../utils/mailer.js';
import { tenantBySlug } from '../middleware/tenant.js';
import { requireUser } from '../middleware/auth.js';
import Order from '../models/Order.js';
import Coupon from '../models/Coupon.js';
import Site from '../models/Site.js';
import { calculateDistanceFeeCents, distanceBetweenAddressesKm } from '../services/geo.js';
import { getNextOrderNumber } from '../utils/orderNumber.js';

const router = Router();

// Helper: Notify external API after order events (default to Blueboxx backend)
const ORDER_NOTIFY_URL_FALLBACK = process.env.ORDER_NOTIFY_URL || 'https://blueboxx-backend.onrender.com/api/order/notify';
function buildNotifyPayload(order, siteName) {
  return {
    _id: String(order?._id || ''),
    site: siteName || '',
    userId: order?.userId ? String(order.userId) : undefined,
    userEmail: order?.userEmail || '',
    fulfillmentType: order?.fulfillmentType,
    items: (order?.items || []).map((m) => ({
      name: m.name,
      quantity: m.quantity,
      priceCents: m.priceCents,
      size: m.size,
      spiceLevel: m.spiceLevel,
      flavor: m.flavor,
      portion: m.portion,
      quantityOption: m.quantityOption,
    })),
    totalCents: order?.totalCents,
    taxCents: order?.taxCents,
    tipCents: typeof order?.tipCents === 'number' ? order.tipCents : 0,
    deliveryFeeCents: typeof order?.deliveryFeeCents === 'number' ? order.deliveryFeeCents : 0,
    deliveryFeeRestaurantCents: typeof order?.deliveryFeeRestaurantCents === 'number' ? order.deliveryFeeRestaurantCents : 0,
    notes: order?.notes || '',
    status: order?.status,
    pickup: order?.pickup,
    dropoff: order?.dropoff,
    meta: order?.meta,
    createdAt: order?.createdAt,
    updatedAt: order?.updatedAt,
    externalId: order?.externalId,
  };
}
async function sendOrderNotify(order, siteName, siteNotifyUrl) {
  try {
    const payload = buildNotifyPayload(order, siteName);
    const url = siteNotifyUrl || ORDER_NOTIFY_URL_FALLBACK;
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
  } catch {}
}

// Stripe payment confirmation fallback.
// Called by frontend after redirect from Stripe (success_url contains cs={CHECKOUT_SESSION_ID}).
router.get('/confirm/:sessionId', async (req, res) => {
  try {
    const sessionId = String(req.params.sessionId || '').trim();
    if (!sessionId) return res.status(400).json({ error: 'Missing session id' });
    // Try to resolve site from order by externalId to use per-site Stripe key if configured
    let siteForClient = null;
    try {
      const byExternal = await Order.findOne({ externalId: sessionId });
      if (byExternal) {
        siteForClient = await Site.findById(byExternal.site);
      }
    } catch {}
    const stripe = getStripeClient(siteForClient);

    const session = await stripe.checkout.sessions.retrieve(sessionId);
    if (!session) return res.status(404).json({ error: 'Session not found' });
    const paid = (session.payment_status === 'paid') || (session.status === 'complete');
    const orderId = session.metadata?.orderId;
    const siteId = session.metadata?.siteId;
    if (!orderId || !siteId) return res.status(400).json({ error: 'Missing order or site metadata' });

    let updatedOrder = null;
    if (paid) {
      // Mark order paid
      updatedOrder = await Order.findByIdAndUpdate(orderId, { status: 'paid' }, { new: true });
      // Assign missing order number now if needed
      if (updatedOrder && !updatedOrder.orderNumber) {
        try {
          const assigned = await getNextOrderNumber(updatedOrder.site);
          updatedOrder = await Order.findByIdAndUpdate(updatedOrder._id, { orderNumber: assigned }, { new: true });
        } catch {}
      }
      if (updatedOrder && updatedOrder.fulfillmentType === 'delivery' && !updatedOrder.uberDeliveryId) {
        // Create delivery now (same logic as webhook)
        const site = await Site.findById(updatedOrder.site);
        if (updatedOrder?.dropoff && updatedOrder?.pickup?.location && site) {
          const provider = site.deliveryProvider || 'uber';
          let delivery = null;
          if (provider === 'doordash' && site.doordashStoreId) {
            delivery = await ddCreateDelivery({
              storeId: site.doordashStoreId,
              pickup: updatedOrder.pickup.location,
              dropoff: updatedOrder.dropoff,
              manifestItems: (updatedOrder.items || []).map((m) => ({ name: m.name, quantity: m.quantity, size: m.size, price: m.priceCents, spiceLevel: m.spiceLevel, flavor: m.flavor, portion: m.portion })),
              tip: 0,
              externalId: String(updatedOrder._id),
            });
          } else if (site.uberCustomerId) {
            delivery = await uberCreateDelivery({
              customerId: site.uberCustomerId,
              pickup: updatedOrder.pickup.location,
              dropoff: updatedOrder.dropoff,
              manifestItems: (updatedOrder.items || []).map((m) => ({ name: m.name, quantity: m.quantity, size: m.size, price: m.priceCents, spiceLevel: m.spiceLevel, flavor: m.flavor, portion: m.portion })),
              tip: 0,
              externalId: String(updatedOrder._id),
              creds: {
                clientId: site?.uberClientId,
                clientSecret: site?.uberClientSecret,
                env: site?.uberEnv,
                audience: String(site?.uberEnv || '').toLowerCase() === 'sandbox'
                  ? 'https://sandbox-api.uber.com'
                  : 'https://api.uber.com',
              }
            });
          }
          if (delivery) {
            const trackingUrl = delivery?.tracking_url || delivery?.trackingUrl || delivery?.share_url || '';
            const status = delivery?.status || delivery?.state || delivery?.current_status || '';
            await Order.findByIdAndUpdate(updatedOrder._id, { uberDeliveryId: delivery?.id || delivery?.delivery_id, uberTrackingUrl: trackingUrl, uberStatus: status });
          }
        }
      }
      try {
        const site = await Site.findById(siteId);
        await sendOrderEmail({ to: updatedOrder?.userEmail, siteName: site?.name || '', orderId: updatedOrder?._id, orderNumber: updatedOrder?.orderNumber, items: updatedOrder?.items, totalCents: updatedOrder?.totalCents, deliveryFeeCents: updatedOrder?.deliveryFeeCents, fulfillmentType: updatedOrder?.fulfillmentType, trackingUrl: updatedOrder?.uberTrackingUrl });
        await sendOrderNotify(updatedOrder, site?.name || '', site?.orderNotifyUrl);
      } catch {}
    }

    return res.json({ ok: true, paid, orderId });
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }
});

// Resolve by :slug for all endpoints here
router.use('/:slug', tenantBySlug);

function getStripeClient(site) {
  const siteSecret = site?.stripeSecretKey;
  const secret = siteSecret || process.env.STRIPE_SECRET_KEY;
  if (!secret) throw new Error('Missing STRIPE_SECRET_KEY');
  // Explicitly pin to a modern API version.
  // Note: We'll use Checkout session-level discounts with product scoping to show a visible Discount row.
  return new Stripe(secret, { apiVersion: process.env.STRIPE_API_VERSION || '2024-06-20' });
}

function getCurrency(site) {
  const cur = (site?.currency || process.env.STRIPE_CURRENCY || 'usd').toLowerCase();
  return cur;
}

// Create Stripe Checkout session for a pickup order
router.post('/:slug/checkout/pickup', requireUser, async (req, res) => {
  try {
    const stripe = getStripeClient(req.site);
    const currency = getCurrency(req.site);
    const { items = [], pickup, notes, coupon } = req.body || {};

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Items required' });
    }

    // Compute items subtotal in cents
    const itemsSubtotal = items.reduce((sum, it) => sum + (Number(it.priceCents) || 0) * (Number(it.quantity) || 1), 0);
    const COUPON_MIN_SUBTOTAL_CENTS = (typeof req.site?.couponMinSubtotalCents === 'number')
      ? Math.max(0, Number(req.site.couponMinSubtotalCents) || 0)
      : Math.max(0, Number(process.env.COUPON_MIN_SUBTOTAL_CENTS) || 5000);
    const subtotalBeforeDiscount = itemsSubtotal;

    // Validate coupon by code only; ignore client percent and use server value
    let appliedCoupon = null;
    const code = coupon?.code ? String(coupon.code).trim().toUpperCase() : null;
    const mock = req.app.locals.mockData;
    if (code && subtotalBeforeDiscount >= COUPON_MIN_SUBTOTAL_CENTS) {
      if (mock) {
        const found = (mock.coupons || []).find((c) => c.site === req.siteId && c.code === code);
        if (found) appliedCoupon = { code, percent: Math.max(0, Math.min(100, Number(found.percent) || 0)) };
      } else {
        const found = await Coupon.findOne({ site: req.siteId, code });
        if (found) appliedCoupon = { code, percent: Math.max(0, Math.min(100, Number(found.percent) || 0)) };
      }
    }

    const isMockEnv = !!req.app?.locals?.mockData;
    const minOrderCents = isMockEnv ? 0 : ((typeof req.site?.minOrderCents === 'number')
      ? Math.max(0, Number(req.site.minOrderCents) || 0)
      : Math.max(0, Number(process.env.MIN_ORDER_CENTS) || 5000));
    if (subtotalBeforeDiscount < minOrderCents) {
      return res.status(400).json({ error: `Minimum order is $${(minOrderCents/100).toFixed(2)}` });
    }

    // Totals after discount (used for our Order record and tax line)
    // Compute discount at per-LINE level to mirror Stripe's rounding for Checkout discounts
    const pctOff = appliedCoupon ? Number(appliedCoupon.percent) || 0 : 0;
    const discountedItemsSubtotal = items.reduce((sum, it) => {
      const unit = Math.max(0, Number(it.priceCents) || 0);
      const qty = Number(it.quantity) || 1;
      const lineTotal = unit * qty;
      const discountedLine = pctOff > 0 ? Math.round(lineTotal * (100 - pctOff) / 100) : lineTotal;
      return sum + discountedLine;
    }, 0);
    const itemsTotalAfterDiscount = Math.max(0, discountedItemsSubtotal);
    const discountCents = Math.max(0, itemsSubtotal - itemsTotalAfterDiscount);
    const taxCents = Math.round(itemsTotalAfterDiscount * 0.05);
    const totalCents = itemsTotalAfterDiscount + taxCents;

    const orderPayload = {
      site: req.siteId,
      userId: req.user?.userId,
      userEmail: req.user?.email,
      items: items.map((m) => ({
        name: m.name,
        quantity: m.quantity,
        priceCents: m.priceCents,
        size: m.size,
        spiceLevel: m.spiceLevel,
        flavor: m.flavor,
        portion: m.portion,
        quantityOption: m.quantityOption,
      })),
      totalCents,
      taxCents,
      tipCents: 0,
      fulfillmentType: 'pickup',
      pickup,
      notes: typeof notes === 'string' ? notes.slice(0, 1000) : undefined,
      meta: appliedCoupon ? { coupon: appliedCoupon } : undefined,
      status: 'awaiting_payment',
    };

    // Create order now so webhook can mark it paid later
    // Assign a human-friendly order number IMMEDIATELY so UI/PDFs never show a blank value
    let orderId;
    if (mock) {
      if (!Array.isArray(req.app.locals.mockData.orders)) req.app.locals.mockData.orders = [];
      const createdAt = new Date().toISOString();
      const nextSeq = ((req.app.locals.mockData.orderSeq || 1000) + 1);
      req.app.locals.mockData.orderSeq = nextSeq;
      const created = { _id: `o-${Date.now()}`, createdAt, orderNumber: `BB-${nextSeq}`, ...orderPayload };
      req.app.locals.mockData.orders.unshift(created);
      orderId = created._id;
    } else {
      const orderNumber = await getNextOrderNumber(req.siteId);
      const created = await Order.create({ ...orderPayload, orderNumber });
      orderId = created._id;
    }

    const origin = req.get('origin') || process.env.FRONTEND_URL || 'http://localhost:5173';
    const slug = String(req.params.slug);

    // Build line items with UN-discounted unit prices, and attach a Checkout discount scoped to items only.
    // Move tax calculation display to Stripe via a 5% exclusive tax rate on item lines.
    async function ensureTaxRateId() {
      // Try to find an existing matching 5% exclusive tax rate to avoid creating many duplicates
      try {
        const list = await stripe.taxRates.list({ active: true, limit: 100 });
        const found = list.data.find((tr) => tr.display_name === 'Tax' && tr.inclusive === false && Math.round(Number(tr.percentage) * 100) === 500);
        if (found) return found.id;
      } catch {}
      const created = await stripe.taxRates.create({ display_name: 'Tax', percentage: 5, inclusive: false });
      return created.id;
    }

    const taxRateId = await ensureTaxRateId();

    // Create concrete Product objects so we can scope the discount to items only
    const itemProducts = await Promise.all(items.map(async (it) => {
      const flavorText = it.flavor ? ` — Flavor: ${it.flavor}` : '';
      const portionText = it.portion ? ` — Portion: ${it.portion}` : '';
      const qtyText = it.quantityOption ? ` — Quantity: ${it.quantityOption}` : '';
      const name = `${it.name}${it.size ? ' — Select Item: ' + it.size : ''}${flavorText}${portionText}${qtyText}`;
      const p = await stripe.products.create({ name });
      return p.id;
    }));

    const lineItems = [
      ...items.map((it, idx) => ({
        price_data: {
          currency,
          product: itemProducts[idx],
          unit_amount: Math.max(0, Number(it.priceCents) || 0),
        },
        quantity: Number(it.quantity) || 1,
        tax_rates: [taxRateId],
      })),
    ];

    // Create a one-time coupon to show Discount row (scoped to item products only)
    let discountsField = undefined;
    if (pctOff > 0 && discountCents > 0) {
      const couponStripe = await stripe.coupons.create({
        percent_off: pctOff,
        duration: 'once',
        applies_to: { products: itemProducts },
        name: appliedCoupon?.code ? `Coupon ${appliedCoupon.code}` : 'Discount',
      });
      discountsField = [{ coupon: couponStripe.id }];
    }

    // Build PI data depending on per-site vs Connect
    const usePerSiteStripe = !!req.site?.stripeSecretKey;
  const piDataPickup = (!usePerSiteStripe && req.site?.stripeAccountId) ? {
      transfer_data: { destination: req.site.stripeAccountId },
      on_behalf_of: req.site.stripeAccountId,
    } : undefined;

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: lineItems,
      discounts: discountsField,
      success_url: `${origin}/s/${encodeURIComponent(slug)}/orders?status=success&cs={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/s/${encodeURIComponent(slug)}?status=cancelled`,
      customer_email: req.user?.email || undefined,
      payment_intent_data: piDataPickup,
      metadata: {
        orderId: String(orderId),
        siteId: String(req.siteId),
        siteSlug: slug,
        fulfillmentType: 'pickup',
      },
    });

    // Update order with external checkout session id
    if (mock) {
      const list = req.app.locals.mockData.orders || [];
      const idx = list.findIndex((o) => String(o._id) === String(orderId));
      if (idx >= 0) list[idx].externalId = session.id;
    } else {
      await Order.findByIdAndUpdate(orderId, { externalId: session.id });
    }

    return res.status(200).json({ url: session.url, sessionId: session.id });
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }
});

// Create Stripe Checkout session for a delivery order (Uber created after payment via webhook)
router.post('/:slug/checkout/delivery', requireUser, async (req, res) => {
  try {
    const stripe = getStripeClient(req.site);
    const currency = getCurrency(req.site);
    const { dropoff, manifestItems = [], pickupLocationIndex, notes, coupon, deliveryFeeCents: clientDeliveryFeeCents } = req.body || {};
    const mock = req.app.locals.mockData;

    if (!Array.isArray(manifestItems) || manifestItems.length === 0) {
      return res.status(400).json({ error: 'Items required' });
    }

    let site;
    if (mock) {
      site = (req.app.locals.mockData.sites || []).find((s) => s._id === req.siteId);
    } else {
      site = await Site.findById(req.siteId);
    }
    if (!site) return res.status(404).json({ error: 'Site not found' });

    const locs = (Array.isArray(site.locations) && site.locations.length)
      ? site.locations
      : (site.pickup ? [site.pickup] : []);
    if (!locs.length) return res.status(400).json({ error: 'No pickup location configured' });
    const chosenIdx = (typeof pickupLocationIndex === 'number' && locs[pickupLocationIndex]) ? pickupLocationIndex : 0;
    const pickup = locs[chosenIdx];

    // Items subtotal and coupon validation (apply per-item discount; ignore client percent)
    const itemsSubtotal = manifestItems.reduce((sum, it) => sum + (Number(it.priceCents) || 0) * (Number(it.quantity) || 1), 0);
    const COUPON_MIN_SUBTOTAL_CENTS = (typeof req.site?.couponMinSubtotalCents === 'number')
      ? Math.max(0, Number(req.site.couponMinSubtotalCents) || 0)
      : Math.max(0, Number(process.env.COUPON_MIN_SUBTOTAL_CENTS) || 5000);
    const subtotalBeforeDiscount = itemsSubtotal;
    let appliedCoupon = null;
    if (coupon && coupon.code && subtotalBeforeDiscount >= COUPON_MIN_SUBTOTAL_CENTS) {
      const code = String(coupon.code).trim().toUpperCase();
      if (mock) {
        const found = (req.app.locals.mockData.coupons || []).find((c) => c.site === req.siteId && c.code === code);
        if (found) { appliedCoupon = { code, percent: Math.max(0, Math.min(100, Number(found.percent) || 0)) }; }
      } else {
        const found = await Coupon.findOne({ site: req.siteId, code });
        if (found) { appliedCoupon = { code, percent: Math.max(0, Math.min(100, Number(found.percent) || 0)) }; }
      }
    }

    const isMockEnv = !!req.app?.locals?.mockData;
    const minOrderCents = isMockEnv ? 0 : ((typeof req.site?.minOrderCents === 'number')
      ? Math.max(0, Number(req.site.minOrderCents) || 0)
      : Math.max(0, Number(process.env.MIN_ORDER_CENTS) || 5000));
    if (subtotalBeforeDiscount < minOrderCents) return res.status(400).json({ error: `Minimum total amount should be $${(minOrderCents/100).toFixed(2)} required for delivery` });

    // Compute delivery fee based on distance; do not block here on max km
    let distanceKm = null;
    try { distanceKm = await distanceBetweenAddressesKm(pickup.address, dropoff?.address); } catch {}
    // Max-distance validation is handled earlier (Fulfillment modal via /delivery/quote)
    // Compute delivery fee using admin-configured per-km rate (cents/km)
    const baseFee = (typeof site?.deliveryFeeCents === 'number' && isFinite(site.deliveryFeeCents))
      ? Math.max(0, Number(site.deliveryFeeCents))
      : 800;
    const fullDeliveryFeeCents = calculateDistanceFeeCents(distanceKm, baseFee);
    const split = !!site.splitDeliveryFee;
    // Free-delivery eligibility is based on items subtotal BEFORE discount
    const freeEnabled = !!site.freeDeliveryEnabled;
    const freeMinCents = (typeof site.freeDeliveryMinSubtotalCents === 'number')
      ? Math.max(0, Number(site.freeDeliveryMinSubtotalCents) || 0)
      : null;
    const freeEligible = !!freeEnabled && freeMinCents !== null && subtotalBeforeDiscount >= freeMinCents;

    let customerDeliveryFeeCents = split ? Math.round(fullDeliveryFeeCents / 2) : fullDeliveryFeeCents;
    // By default, baseline is what we computed from distance; if client quoted, we'll override (unless free applies)
    let baselineDeliveryFeeCents = fullDeliveryFeeCents;
    let restaurantDeliveryFeeCents = split ? (fullDeliveryFeeCents - customerDeliveryFeeCents) : 0;

    if (freeEligible) {
      // Customer pays $0 delivery; restaurant covers full delivery via application fee
      customerDeliveryFeeCents = 0;
      baselineDeliveryFeeCents = fullDeliveryFeeCents;
      restaurantDeliveryFeeCents = fullDeliveryFeeCents;
    } else if (typeof clientDeliveryFeeCents === 'number') {
      // Trust the client-quoted delivery fee exactly to keep cart and payment in sync
      const quoted = Math.max(0, Math.round(Number(clientDeliveryFeeCents)));
      customerDeliveryFeeCents = quoted;
      // Use client's quote to derive the baseline so the split stays consistent end-to-end
      baselineDeliveryFeeCents = split ? (quoted * 2) : quoted;
      restaurantDeliveryFeeCents = split ? Math.max(0, baselineDeliveryFeeCents - quoted) : 0;
    }

    // Recompute discount at per-LINE level to mirror Stripe's rounding when using coupon discounts
    const discountedItemsSubtotalDel = manifestItems.reduce((sum, it) => {
      const unit = Math.max(0, Number(it.priceCents || it.price) || 0);
      const qty = Number(it.quantity) || 1;
      const lineTotal = unit * qty;
      const pct = appliedCoupon ? Number(appliedCoupon.percent) || 0 : 0;
      const discountedLine = pct > 0 ? Math.round(lineTotal * (100 - pct) / 100) : lineTotal;
      return sum + discountedLine;
    }, 0);
    const itemsTotalAfterDiscount = Math.max(0, discountedItemsSubtotalDel);
    const discountCents = Math.max(0, itemsSubtotal - itemsTotalAfterDiscount);
    const taxCents = Math.round(itemsTotalAfterDiscount * 0.05);
    const totalCents = itemsTotalAfterDiscount + taxCents + customerDeliveryFeeCents;

    // Create order (awaiting_payment). Uber delivery will be created on webhook after payment
    const orderPayload = {
      site: req.siteId,
      userId: req.user?.userId,
      userEmail: req.user?.email,
      items: manifestItems.map((m) => ({ name: m.name, quantity: m.quantity, priceCents: m.priceCents || m.price || 0, size: m.size, spiceLevel: m.spiceLevel, flavor: m.flavor, portion: m.portion, quantityOption: m.quantityOption })),
      totalCents,
      taxCents,
      deliveryFeeCents: customerDeliveryFeeCents,
      deliveryFeeRestaurantCents: restaurantDeliveryFeeCents,
      fulfillmentType: 'delivery',
      dropoff,
      pickup: { location: pickup },
      notes: typeof notes === 'string' ? notes.slice(0, 1000) : undefined,
      // Include coupon metadata so PDFs can render a Discount row later
      meta: appliedCoupon
        ? { distanceKm, coupon: appliedCoupon, freeDeliveryApplied: !!freeEligible }
        : { distanceKm, freeDeliveryApplied: !!freeEligible },
      status: 'awaiting_payment',
    };
    let orderId;
    if (mock) {
      if (!Array.isArray(req.app.locals.mockData.orders)) req.app.locals.mockData.orders = [];
      const createdAt = new Date().toISOString();
      const nextSeq = ((req.app.locals.mockData.orderSeq || 1000) + 1);
      req.app.locals.mockData.orderSeq = nextSeq;
      const created = { _id: `o-${Date.now()}`, createdAt, orderNumber: `BB-${nextSeq}`, ...orderPayload };
      req.app.locals.mockData.orders.unshift(created);
      orderId = created._id;
    } else {
      const orderNumber = await getNextOrderNumber(req.siteId);
      const created = await Order.create({ ...orderPayload, orderNumber });
      orderId = created._id;
    }

    const origin = req.get('origin') || process.env.FRONTEND_URL || 'http://localhost:5173';
    const slug = String(req.params.slug);

    const pctOffDel = appliedCoupon ? Number(appliedCoupon.percent) || 0 : 0;

    const usePerSiteStripeDel = !!site?.stripeSecretKey;
    const piDataDelivery = (!usePerSiteStripeDel && site?.stripeAccountId) ? {
      transfer_data: { destination: site.stripeAccountId },
      // Collect full delivery fee on the platform:
      // - When split is ON: 50% from customer via line item, and the remaining 50%
      //   is deducted from the restaurant payout via application fee
      // - When split is OFF: full delivery fee comes from the customer, and we
      //   still collect it via application fee so the restaurant net is items + tax
      application_fee_amount: baselineDeliveryFeeCents,
      on_behalf_of: site.stripeAccountId,
    } : undefined;

    // Use UN-discounted unit prices on items and attach a visible Discount via a session coupon.
    // Apply a 5% exclusive tax rate on item lines so Stripe renders the Tax row properly (and the discount applies before tax).
    async function ensureTaxRateIdDel() {
      try {
        const list = await stripe.taxRates.list({ active: true, limit: 100 });
        const found = list.data.find((tr) => tr.display_name === 'Tax' && tr.inclusive === false && Math.round(Number(tr.percentage) * 100) === 500);
        if (found) return found.id;
      } catch {}
      const created = await stripe.taxRates.create({ display_name: 'Tax', percentage: 5, inclusive: false });
      return created.id;
    }
    const taxRateIdDel = await ensureTaxRateIdDel();

    const itemProductsDel = await Promise.all(manifestItems.map(async (it) => {
      const flavorText = it.flavor ? ` — Flavor: ${it.flavor}` : '';
      const portionText = it.portion ? ` — Portion: ${it.portion}` : '';
      const qtyText = it.quantityOption ? ` — Quantity: ${it.quantityOption}` : '';
      const name = `${it.name}${it.size ? ' — Select Item: ' + it.size : ''}${flavorText}${portionText}${qtyText}`;
      const p = await stripe.products.create({ name });
      return p.id;
    }));

    const lineItemsDel = [
      ...manifestItems.map((it, idx) => ({
        price_data: { currency, product: itemProductsDel[idx], unit_amount: Math.max(0, Number(it.priceCents || it.price) || 0) },
        quantity: Number(it.quantity) || 1,
        tax_rates: [taxRateIdDel],
      })),
      ...(customerDeliveryFeeCents > 0 ? [{ price_data: { currency, product_data: { name: 'Delivery fee' }, unit_amount: customerDeliveryFeeCents }, quantity: 1 }] : []),
    ];

    // Create a one-time percent-off coupon for the session, scoped to item products only
    let discountsFieldDel = undefined;
    if (pctOffDel > 0 && discountCents > 0) {
      const couponStripeDel = await stripe.coupons.create({
        percent_off: pctOffDel,
        duration: 'once',
        applies_to: { products: itemProductsDel },
        name: appliedCoupon?.code ? `Coupon ${appliedCoupon.code}` : 'Discount',
      });
      discountsFieldDel = [{ coupon: couponStripeDel.id }];
    }

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: lineItemsDel,
      discounts: discountsFieldDel,
      success_url: `${origin}/s/${encodeURIComponent(slug)}/orders?status=success&cs={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/s/${encodeURIComponent(slug)}?status=cancelled`,
      customer_email: req.user?.email || undefined,
      payment_intent_data: piDataDelivery,
      metadata: {
        orderId: String(orderId),
        siteId: String(req.siteId),
        siteSlug: slug,
        fulfillmentType: 'delivery',
      },
    });

    if (mock) {
      const list = req.app.locals.mockData.orders || [];
      const idx = list.findIndex((o) => String(o._id) === String(orderId));
      if (idx >= 0) list[idx].externalId = session.id;
    } else {
      await Order.findByIdAndUpdate(orderId, { externalId: session.id });
    }

    return res.status(200).json({ url: session.url, sessionId: session.id });
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }
});

export default router;

