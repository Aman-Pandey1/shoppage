import React from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { fetchJson, getAuthToken, getCurrentUser } from '../lib/api';
import { useSiteQuery } from '../lib/queries';
import { download } from '../lib/api';
import { LoginModal } from '../components/LoginModal';
import { TrackingModal } from '../components/TrackingModal';

export const MyOrdersPage = () => {
  const params = useParams();
  const siteSlug = params.siteSlug;
  const location = useLocation();
  const { data: siteInfo } = useSiteQuery(siteSlug || 'default');
  const siteTz = (siteInfo && siteInfo.timeZone) ? siteInfo.timeZone : 'America/Edmonton';
  const [orders, setOrders] = React.useState([]);
  const [page, setPage] = React.useState(1);
  const [pageSize, setPageSize] = React.useState(12);
  const [totalPages, setTotalPages] = React.useState(1);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState();
  const [query, setQuery] = React.useState('');
  const [loginOpen, setLoginOpen] = React.useState(false);
  const [tab, setTab] = React.useState('all'); // all | pickup | delivery
  const [tracking, setTracking] = React.useState({});
  const [trackingLoadingId, setTrackingLoadingId] = React.useState('');
  const [trackingError, setTrackingError] = React.useState('');
  const [trackingModal, setTrackingModal] = React.useState({ open: false, url: '', status: '' });
  const [successMsg, setSuccessMsg] = React.useState('');

  // Detect success status in query params (e.g., from COD or Stripe)
  React.useEffect(() => {
    try {
      const sp = new URLSearchParams(location.search || window.location.search || '');
      const status = (sp.get('status') || '').toLowerCase();
      const cs = sp.get('cs'); // Stripe checkout session id
      if (status === 'placed' || status === 'success') {
        setSuccessMsg(status === 'success' ? 'Payment successful! Your order has been placed.' : 'Order placed! Your order has been created.');
        // If coming from Stripe success, confirm on backend in case webhook missed
        if (cs) {
          (async () => {
            try {
              await fetchJson(`/api/payments/stripe/confirm/${encodeURIComponent(cs)}`);
            } catch {}
          })();
        }
        // Clean the query param from the URL without reload
        try {
          const clean = window.location.pathname + window.location.hash;
          window.history.replaceState({}, document.title, clean || '/');
        } catch {}
      }
    } catch {}
  }, [location.search]);

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        if (!getAuthToken()) {
          setLoginOpen(true);
          if (mounted) {
            setOrders([]);
            setLoading(false);
          }
          return;
        }
        const data = await fetchJson(`/api/shop/${siteSlug || 'default'}/orders/mine?page=${page}&pageSize=${pageSize}`);
        if (mounted) {
          if (Array.isArray(data)) {
            setOrders(data);
            setTotalPages(1);
          } else {
            setOrders(Array.isArray(data?.items) ? data.items : []);
            setTotalPages(Number(data?.totalPages) || 1);
          }
        }
      } catch (e) {
        const msg = String(e?.message || '');
        if (/401|403/.test(msg)) {
          if (mounted) {
            setLoginOpen(true);
            setError(undefined);
          }
        } else {
          if (mounted) setError(e.message || 'Failed to load orders');
        }
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [siteSlug, page, pageSize]);

  const filtered = React.useMemo(() => {
    let list = Array.isArray(orders) ? orders : [];
    if (tab !== 'all') list = list.filter((o) => (o.fulfillmentType || '').toLowerCase() === tab);
    if (!query.trim()) return list;
    const q = query.toLowerCase();
    return list.filter((o) => {
      const idStr = String(o?._id || '').toLowerCase();
      const orderNum = String(o?.orderNumber || '').toLowerCase();
      const items = Array.isArray(o?.items) ? o.items : [];
      return idStr.includes(q) || orderNum.includes(q) || items.some((it) => String(it?.name || '').toLowerCase().includes(q));
    });
  }, [orders, query, tab]);

  if (loading) return (
    <div className="loading-center">
      <div className="spinner" aria-label="Loading orders" />
    </div>
  );
  if (error) return <div style={{ color: 'red' }}>{error}</div>;

  return (
    <div className="container" style={{ paddingTop: 20 }}>
      {successMsg ? (
        <div className="card" style={{ padding: 12, marginBottom: 12, borderLeft: '4px solid var(--green-600)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }} role="status" aria-live="polite">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span>✅</span>
            <div style={{ fontWeight: 700 }}>{successMsg}</div>
          </div>
          <button onClick={() => setSuccessMsg('')}>Dismiss</button>
        </div>
      ) : null}
      <div className="card" style={{ padding: 12, marginBottom: 12, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontWeight: 900, fontSize: 18 }}>My Orders</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className={tab === 'all' ? 'primary-btn' : ''} onClick={() => setTab('all')}>All</button>
          <button className={tab === 'pickup' ? 'primary-btn' : ''} onClick={() => setTab('pickup')}>Takeout</button>
          <button className={tab === 'delivery' ? 'primary-btn' : ''} onClick={() => setTab('delivery')}>Delivery</button>
        </div>
      </div>
      <div className="card" style={{ padding: 8, borderRadius: 12, marginBottom: 10 }}>
        <input placeholder="Search my orders by item or order #" value={query} onChange={(e) => setQuery(e.target.value)} />
      </div>
      {filtered.length === 0 ? (
        <div className="muted">No orders yet.</div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
          {filtered.map((o) => (
            <div key={o._id} className="card" style={{ padding: 12, borderTop: `3px solid ${o.fulfillmentType === 'delivery' ? 'var(--primary)' : 'var(--green-600)'}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ fontSize: 18 }}>{o.fulfillmentType === 'delivery' ? '🚚' : '🏪'}</div>
                  <div style={{ fontWeight: 800 }}>{o.orderNumber || `BB-${String(o._id).slice(-6)}`}</div>
                </div>
                <div className="muted" style={{ fontSize: 12, color: 'var(--primary-600)' }}>{(function(){
                  try {
                    const tz = siteTz || 'America/Edmonton';
                    return new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: tz, timeZoneName: 'short' }).format(new Date(o.createdAt));
                  } catch { return new Date(o.createdAt).toLocaleString(); }
                })()}</div>
              </div>
              <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>{o.fulfillmentType === 'delivery' ? 'Delivery' : 'Takeout'}</div>
              <ul style={{ margin: '8px 0', paddingLeft: 18 }}>
                {(Array.isArray(o.items) ? o.items : []).map((it, idx) => (
                  <li key={idx}>
                    {it.name}
                    {it.flavor ? ` — Flavor: ${it.flavor}` : ''}
                    {it.portion ? ` — Portion: ${it.portion}` : ''}
                    {it.spiceLevel ? ` [${it.spiceLevel}]` : ''}
                    {it.size ? ` — Select Item: ${it.size}` : ''}
                    {it.portion ? ` — Portion: ${it.portion}` : ''}
                    {it.flavor ? ` — Flavor: ${it.flavor}` : ''}
                    {it.quantityOption ? ` — Quantity: ${it.quantityOption}` : ''}
                    × {it.quantity}
                  </li>
                ))}
              </ul>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ fontWeight: 900, color: 'var(--primary-600)' }}>${(o.totalCents/100).toFixed(2)}</div>
                {o.meta?.coupon ? (
                  <div className="muted" style={{ fontSize: 12, textAlign: 'right' }}>
                    Coupon: {o.meta.coupon.code} ({o.meta.coupon.percent}% off)
                  </div>
                ) : null}
                {o.fulfillmentType === 'delivery' && o.dropoff?.address ? (
                  <div className="muted" style={{ fontSize: 12, textAlign: 'right' }}>
                    {o.dropoff.address.city}
                  </div>
                ) : null}
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                <button onClick={async () => {
                  try {
                    let blob;
                    const initialSlug = siteSlug || 'default';
                    // 1) Prefer legacy slugless endpoint first (resolves site from order and enforces ownership)
                    try {
                      blob = await download(`/api/shop/orders/${o._id}/pdf`);
                    } catch (err0) {
                      const msg0 = String(err0?.message || '');
                      if (/\b401\b/.test(msg0) || /Missing token/i.test(msg0)) {
                        setLoginOpen(true);
                        throw err0;
                      }
                      // 2) Try slug-based with current route slug
                      if (!blob && (/\b404\b/i.test(msg0) || /\b403\b/i.test(msg0))) {
                        try {
                          blob = await download(`/api/shop/${initialSlug}/orders/${o._id}/pdf`);
                        } catch (err1) {
                          const msg1 = String(err1?.message || '');
                          if (/\b401\b/.test(msg1) || /Missing token/i.test(msg1)) {
                            setLoginOpen(true);
                            throw err1;
                          }
                          // 2a) Re-resolve slug from host and retry once
                          if (/\b404\b/i.test(msg1) || /Site not found/i.test(msg1) || /\b403\b/i.test(msg1)) {
                            try {
                              const hostSite = await fetchJson(`/api/shop/host-site`);
                              const resolvedSlug = hostSite?.slug || initialSlug;
                              if (resolvedSlug) {
                                try {
                                  blob = await download(`/api/shop/${resolvedSlug}/orders/${o._id}/pdf`);
                                } catch {}
                              }
                            } catch {}
                          }
                          // 3) If admin is logged in, use admin endpoint as last resort
                          if (!blob) {
                            try {
                              const user = getCurrentUser();
                              const siteId = siteInfo?.siteId;
                              if (user?.role === 'admin' && siteId) {
                                blob = await download(`/api/admin/sites/${siteId}/orders/${o._id}/pdf`);
                              } else {
                                throw err1;
                              }
                            } catch (errFinal) {
                              throw errFinal;
                            }
                          }
                        }
                      } else {
                        // If err wasn't 403/404, rethrow now
                        throw err0;
                      }
                    }
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    const fileId = (o.orderNumber || `BB-${String(o._id).slice(-6)}`).replace(/\s+/g, '');
                    a.href = url; a.download = `order-${fileId}.pdf`; a.click();
                    URL.revokeObjectURL(url);
                  } catch (e) {
                    const msg = String(e?.message || '');
                    if (/\b401\b/.test(msg)) {
                      alert('Please login to download your invoice.');
                    } else if (/\b403\b/.test(msg)) {
                      alert('You can only download invoices for your own orders.');
                    } else if (/\b404\b/.test(msg)) {
                      alert('Invoice not found for this order.');
                    } else {
                      alert('Failed to download invoice');
                    }
                  }
                }}>Download invoice (PDF)</button>
              </div>
              {o.fulfillmentType === 'delivery' ? (
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8 }}>
                  <button
                    onClick={async () => {
                      try {
                        setTrackingError('');
                        setTrackingLoadingId(o._id);
                        const data = await fetchJson(`/api/shop/${siteSlug || 'default'}/orders/${o._id}/tracking`);
                        setTracking(prev => ({ ...prev, [o._id]: data }));
                        setTrackingModal({ open: true, url: data?.uberTrackingUrl || '', status: data?.uberStatus || '' });
                      } catch (e) {
                        setTrackingError(e.message || 'Failed to load tracking');
                      } finally {
                        setTrackingLoadingId('');
                      }
                    }}
                  >{trackingLoadingId === o._id ? 'Loading…' : 'Track live'}</button>
                </div>
              ) : null}
            </div>
          ))}
        </div>
      )}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
        <div className="muted" style={{ fontSize: 12 }}>Page {page} of {totalPages}</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>Prev</button>
          <button disabled={page >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))}>Next</button>
        </div>
      </div>
      <TrackingModal
        open={trackingModal.open}
        trackingUrl={trackingModal.url}
        status={trackingModal.status}
        onClose={() => setTrackingModal({ open: false, url: '', status: '' })}
      />
      <LoginModal
        open={loginOpen}
        onClose={() => setLoginOpen(false)}
        onSuccess={async () => {
          try {
            setLoginOpen(false);
            setLoading(true);
            const data = await fetchJson(`/api/shop/${siteSlug || 'default'}/orders/mine`);
            setOrders(Array.isArray(data) ? data : []);
            setError(undefined);
          } catch (e) {
            const msg = String(e?.message || '');
            if (/401|403/.test(msg)) {
              setLoginOpen(true);
              setError(undefined);
            } else {
              setError(e.message || 'Failed to load orders');
            }
          } finally {
            setLoading(false);
          }
        }}
        mode="user"
      />
    </div>
  );
};

